create view available_books
            (book_id, book_title, book_author, year_of_production, count_of_pages, available_quantity,
             total_quantity) as
SELECT b.book_id,
       b.book_title,
       b.book_author,
       b.year_of_production,
       b.count_of_pages,
       b.count_of_books - COALESCE(bb.booked_quantity, 0::bigint) AS available_quantity,
       b.count_of_books                                           AS total_quantity
FROM books b
         LEFT JOIN (SELECT booked_books.book_id,
                           count(booked_books.book_id) AS booked_quantity
                    FROM booked_books
                    GROUP BY booked_books.book_id) bb ON b.book_id = bb.book_id;

alter table available_books
    owner to postgres;

